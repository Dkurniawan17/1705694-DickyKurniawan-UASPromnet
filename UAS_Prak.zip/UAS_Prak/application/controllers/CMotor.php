<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CMotor extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('Model_Motor');
		$this->API="https://api.akhmad.web.id";
		$this->curl->http_header("X-Nim", "1705694");
	}

	// proses yang akan di buka saat pertama masuk ke controller
	public function index(){
		// $data['user'] = $this->Model_Motor->Get();
		$data['motor'] = json_decode($this->curl->simple_get($this->API.'/motor'));
		$this->load->view('home/index', $data);
	}
	public function cicilan(){
		$data['cicil'] = json_decode($this->curl->simple_get($this->API.'/cicil'));
		$this->load->view('menu/cicil', $data);
	}

	public function uangmuka(){
		$data['dp'] = json_decode($this->curl->simple_get($this->API.'/uangmuka'));
		$this->load->view('menu/dp', $data);
	}

	public function penjualan(){
		$data['penjualan'] = json_decode($this->curl->simple_get($this->API.'/penjualan'));
		$this->load->view('menu/penjualan', $data);
	}
	// proses untuk menambah data
	// insert data kontak
	function add(){
		$this->Model_Motor->Post();
		redirect('CMotor/penjualan');
	}

	function edit($id){
		$this->Model_Motor->Put($id);
		redirect('CMotor/penjualan');
	}

	// proses untuk menghapus data pada database
	function delete($id){
		$this->Model_Motor->Delete($id);
		redirect('CMotor/penjualan');
	}
}
