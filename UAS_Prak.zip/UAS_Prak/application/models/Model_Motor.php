<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_Motor extends CI_Model {

	var $API ="";

	function __construct() {
		parent::__construct();
		$this->API="https://api.akhmad.web.id";
		$this->curl->http_header("X-Nim", "1705694");
	}

	public function Get() {
		return json_decode($this->curl->simple_get($this->API));
	}

	public function Post() {

		$data = array(
		'tipe_motor'      =>  $this->input->post('tipe_motor'),
		'harga_motor'      =>  $this->input->post('harga_motor'),
		'tenor'    =>  $this->input->post('tenor'),
		'uang_muka'    =>  $this->input->post('uang_muka'),
		'cicilan_pokok'	  =>  $this->input->post('cicilan_pokok'),
		'cicilan_bunga'	  =>  $this->input->post('cicilan_bunga'),
		'cicilan_total' =>  $this->input->post('cicilan_total'));

		$insert =  $this->curl->simple_post($this->API.'/penjualan', json_encode($data));

		if($insert)
		{
			$this->session->set_flashdata('hasil','Insert Data Berhasil');
		}else
		{
			$this->session->set_flashdata('hasil','Insert Data Gagal');
		}

	}

	public function Put($id) {

		$data = array(
			'tipe_motor'      =>  $this->input->post('tipe_motor'),
			'harga_motor'      =>  $this->input->post('harga_motor'),
			'tenor'    =>  $this->input->post('tenor'),
			'uang_muka'    =>  $this->input->post('uang_muka'),
			'cicilan_pokok'	  =>  $this->input->post('cicilan_pokok'),
			'cicilan_bunga'	  =>  $this->input->post('cicilan_bunga'),
			'cicilan_total' =>  $this->input->post('cicilan_total'));

		$update =  $this->curl->simple_put($this->API.'/penjualan'.$id, json_encode($data));

		if($update)
		{
			$this->session->set_flashdata('hasil','Insert Data Berhasil');
		}else
		{
			$this->session->set_flashdata('hasil','Insert Data Gagal');
		}

	}

	public function Delete($id) {

			$delete =  $this->curl->simple_delete($this->API.'/penjualan'.$id);

			if($delete)
			{
				$this->session->set_flashdata('hasil','Delete Data Berhasil');
			}else
			{
				$this->session->set_flashdata('hasil','Delete Data Gagal');
			}

	}

}
