<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="">
      <a href="<?php echo base_url('/'); ?>">Home</a>
      <a href="<?php echo base_url('/CMotor/cicilan'); ?>">Cicilan</a>
      <a href="<?php echo base_url('/CMotor/uangmuka'); ?>">DP</a>
      <a href="<?php echo base_url('/CMotor/penjualan'); ?>">Penjualan</a>
    </div>
  </body>
</html>
