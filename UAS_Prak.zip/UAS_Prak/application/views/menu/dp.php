<?php $this->load->view('home/header'); ?>
<div class="container">
  <div class="table-wrapper">
    <div class="table-title">
      <div class="row">
        <div class="col-sm-6">
          <h2>List <b>Motor</b></h2>
        </div>
        <div class="col-sm-6">
        </div>
      </div>
    </div>
    <table class="table table-striped table-hover">
      <thead>
        <tr>
          <th>
            No.
          </th>
          <th>Id</th>
          <th>
            Uang Muka
          </th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <?php
          $i=1;
          foreach ($dp->data as $m) {
            ?>
            <td>
              <?php echo $i; ?>
            </td>
            <td><?php echo $m->id_uang_muka; ?></td>
            <td>
              <?php echo $m->uang_muka ?>
            </td>
            <td>
              <a href="#deleteHpModal<?php echo $m->id_uang_muka;?>" class="delete" data-toggle="modal">Delete</a>
              <a href="#editHpModal<?php echo $m->id_uang_muka;?>" class="edit" data-toggle="modal">Edit</a>
            </td>
          </tr>
          <?php
          $i++;

        }
        ?>
      </tbody>
    </table>

  </div>
</div>
