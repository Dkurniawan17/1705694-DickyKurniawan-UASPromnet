<?php $this->load->view('home/header'); ?>
<div class="container">
  <div class="table-wrapper">
    <div class="table-title">
      <div class="row">
        <div class="col-sm-6">
          <h2>List <b>Motor</b></h2>
        </div>
        <div class="col-sm-6">
        </div>
      </div>
    </div>
    <table class="table table-striped table-hover">
      <thead>
        <tr>
          <th>
            No.
          </th>
          <th>Id</th>
          <th>
            Tenor
          </th>
          <th>Bunga</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <?php
          $i=1;
          foreach ($cicil->data as $m) {
            ?>
            <td>
              <?php echo $i; ?>
            </td>
            <td><?php echo $m->id_cicil ?></td>
            <td>
              <?php echo $m->tenor ?>
            </td>
            <td><?php echo $m->bunga; ?></td>
            <td>
              <a href="#deleteHpModal<?php echo $m->id_cicil;?>" class="delete" data-toggle="modal">Delete</a>
              <a href="#editHpModal<?php echo $m->id_cicil;?>" class="edit" data-toggle="modal">Edit</a>
            </td>
          </tr>
          <?php
          $i++;

        }
        ?>
      </tbody>
    </table>

  </div>
</div>
