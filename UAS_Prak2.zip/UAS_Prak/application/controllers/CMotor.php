<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CMotor extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('Model_Motor');
		$this->API="https://api.akhmad.web.id";
	}

	// proses yang akan di buka saat pertama masuk ke controller
	public function index(){
		$this->curl->http_header("X-Nim", "1705694");
		// $data['user'] = $this->Model_Motor->Get();
		$data['user'] = json_decode($this->curl->simple_get($this->API.'/user'));
		$this->load->view('home/home', $data);
	}

	public function motor(){
		$this->curl->http_header("X-Nim", "1705694");
		$data['motor'] = json_decode($this->curl->simple_get($this->API.'/motor'));
		$this->load->view('home/index', $data);
	}
	public function cicilan(){
		$this->curl->http_header("X-Nim", "1705694");
		$data['cicil'] = json_decode($this->curl->simple_get($this->API.'/cicil'));
		$this->load->view('menu/cicil', $data);
	}

	public function uangmuka(){
		$this->curl->http_header("X-Nim", "1705694");
		$data['dp'] = json_decode($this->curl->simple_get($this->API.'/uangmuka'));
		$this->load->view('menu/dp', $data);
	}

	public function penjualan(){
		$this->curl->http_header("X-Nim", "1705694");
		$data['penjualan'] = json_decode($this->curl->simple_get($this->API.'/penjualan'));
		$this->load->view('menu/penjualan', $data);
	}
	// proses untuk menambah data
	// insert data kontak
	function add(){
		$this->curl->http_header("X-Nim", "1705694");
		$this->Model_Motor->Post();
		redirect('CMotor/penjualan');
	}

	function edit($id){
		$this->curl->http_header("X-Nim", "1705694");
		$this->Model_Motor->Put($id);
		redirect('CMotor/penjualan');
	}

	// proses untuk menghapus data pada database
	function delete($id){
		$this->curl->http_header("X-Nim", "1705694");
		$this->Model_Motor->Delete($id);
		redirect('CMotor/penjualan');
	}
}
