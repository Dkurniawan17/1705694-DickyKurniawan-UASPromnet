<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_Motor extends CI_Model {

	var $API ="";

	function __construct() {
		parent::__construct();
		$this->API="https://api.akhmad.web.id";
		$this->curl->http_header("X-Nim", "1705694");
	}

	public function Get() {
		return json_decode($this->curl->simple_get($this->API));
	}

	public function Post() {

		$data = array(
		'id_motor'      =>  $this->input->post('id_motor'),
		'id_cicil'      =>  $this->input->post('id_cicil'),
		'id_uang_muka'    =>  $this->input->post('id_uang_muka'),
		'cicilan_pokok'	  =>  $this->input->post('cicilan_pokok'),
		'cicilan_bunga'	  =>  $this->input->post('cicilan_bunga'),
		'cicilan_total' =>  $this->input->post('cicilan_total'));

		 $insert =  $this->curl->simple_post($this->API.'/penjualan', $data, array(CURLOPT_BUFFERSIZE => 0));

		if($insert)
		{
			$this->session->set_flashdata('hasil','Insert Data Berhasil');
		}else
		{
			$this->session->set_flashdata('hasil','Insert Data Gagal');
		}

	}

	public function Put($id) {

		$data = array(
			'id_motor'      =>  $this->input->post('id_motor'),
			'id_cicil'      =>  $this->input->post('id_cicil'),
			'id_uang_muka'    =>  $this->input->post('id_uang_muka'),
			'cicilan_pokok'	  =>  $this->input->post('cicilan_pokok'),
			'cicilan_bunga'	  =>  $this->input->post('cicilan_bunga'),
			'cicilan_total' =>  $this->input->post('cicilan_total'));

		 $update =  $this->curl->simple_put($this->API.'/penjualan', $data, array(CURLOPT_BUFFERSIZE => 10));

		if($update)
		{
			$this->session->set_flashdata('hasil','Insert Data Berhasil');
		}else
		{
			$this->session->set_flashdata('hasil','Insert Data Gagal');
		}

	}

	public function Delete($id) {

			$delete =  $this->curl->simple_delete($this->API.'/penjualan'.$id);
			if($delete)
			{
				$this->session->set_flashdata('hasil','Delete Data Berhasil');
			}else
			{
				$this->session->set_flashdata('hasil','Delete Data Gagal');
			}

	}

}
