<?php
/**
 *
 */
class Tes
{
	public function print()
	{
		echo "Hello Wolrd Test";
	}
}

 ?>
